extern const float atan_in[];
extern const float atan_out[];
extern const int atan_N;