float f(float x);
float g(float x);
//void bss(const float de00[],const float e10[],const float e01[],const int N,float mC[3][3]);
