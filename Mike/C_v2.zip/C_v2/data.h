extern const float de00[];
extern const float e01[];
extern const float e10[];
extern const int N;
